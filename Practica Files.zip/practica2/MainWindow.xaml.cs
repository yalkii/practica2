﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace practica2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void OnPlotButtonClick(object sender, RoutedEventArgs e)
        {
            // Получаем коэффициенты k и b из текстовых полей
            if (double.TryParse(KInput.Text, out double k) && double.TryParse(BInput.Text, out double b))
            {
                DrawGraph(k, b);
            }
            else
            {
                MessageBox.Show("Введите корректные значения для k и b.");
            }
        }

        private void DrawGraph(double k, double b)
        {
            // Очищаем канвас перед рисованием нового графика
            GraphCanvas.Children.Clear();

            // Определяем размеры канваса
            double width = GraphCanvas.ActualWidth;
            double height = GraphCanvas.ActualHeight;

            // График будет рисоваться от -Xmax до Xmax
            double Xmax = width / 2;
            double Xmin = -Xmax;

            // Ограничиваем значения Y, чтобы график не выходил за границы канваса
            double Ymax = height / 2;
            double Ymin = -Ymax;

            // Рисуем оси
            DrawAxes();

            // Рисуем линейную функцию Y = kX + b
            Polyline graphLine = new Polyline
            {
                Stroke = Brushes.Blue,
                StrokeThickness = 2
            };

            // Заполняем точки для графика
            for (double x = Xmin; x <= Xmax; x += 1)
            {
                // Вычисляем Y для данной точки
                double y = k * x + b;

                // Ограничиваем значения Y, чтобы они не выходили за пределы канваса
                if (y > Ymax) y = Ymax;
                if (y < Ymin) y = Ymin;

                // Преобразуем координаты из системы координат Xmin..Xmax и Ymin..Ymax в пиксели
                double canvasX = x + Xmax;  // Центрируем на канвасе
                double canvasY = -y + height / 2; // Инвертируем Y для правильного отображения

                // Добавляем точку на график
                graphLine.Points.Add(new System.Windows.Point(canvasX, canvasY));
            }

            // Создаем область обрезки (Clip) для графика
            graphLine.Clip = new RectangleGeometry(new Rect(0, 0, width, height));

            // Добавляем линию на канвас
            GraphCanvas.Children.Add(graphLine);
        }

        private void DrawAxes()
        {
            // Определяем размеры канваса
            double width = GraphCanvas.ActualWidth;
            double height = GraphCanvas.ActualHeight;

            // Рисуем ось X
            Line xAxis = new Line
            {
                X1 = 0,
                Y1 = height / 2,
                X2 = width,
                Y2 = height / 2,
                Stroke = Brushes.Black,
                StrokeThickness = 2
            };
            GraphCanvas.Children.Add(xAxis);

            // Рисуем ось Y
            Line yAxis = new Line
            {
                X1 = width / 2,
                Y1 = 0,
                X2 = width / 2,
                Y2 = height,
                Stroke = Brushes.Black,
                StrokeThickness = 2
            };
            GraphCanvas.Children.Add(yAxis);

            // Добавляем подпись для оси X
            TextBlock xLabel = new TextBlock
            {
                Text = "X",
                FontSize = 14,
                FontWeight = FontWeights.Bold,
                VerticalAlignment = VerticalAlignment.Top,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(width - 40, height / 2 + 10, 0, 0)
            };
            GraphCanvas.Children.Add(xLabel);

            // Добавляем подпись для оси Y
            TextBlock yLabel = new TextBlock
            {
                Text = "Y",
                FontSize = 14,
                FontWeight = FontWeights.Bold,
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Left,
                Margin = new Thickness(400, height / 2 - 130, 570, 1000),
                RenderTransform = new RotateTransform(0)
            };
            GraphCanvas.Children.Add(yLabel);
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
